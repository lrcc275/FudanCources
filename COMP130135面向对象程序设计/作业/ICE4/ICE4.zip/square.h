#ifndef GUARD_square_h
#define GUARD_square_h

#include <vector>
#include <iostream>

class square {
public:
	square() : size(0) {}
	square(int s) :size(s), content(s) {}
	void construct();
	std::ostream& output(std::ostream&);
private:
	int size;
	std::vector<std::vector<int>> content;
};
#endif
