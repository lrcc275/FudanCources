#include <vector>
#include <iostream>
#include <iomanip>
#include "square.h"
using std::ostream;
using std::vector;
using std::endl;
using std::setw;

void square::construct()
{
	bool direction = true; //trueΪ����-�������
	for (int s = 0, i = 1; s < size * 2 - 1; ++s)
	{
		for (int r = 0; r < size; ++r)
		{
			if (s - r >= 0 && s - r < size)
			{
				if (direction) content[r].push_back(i);
				else content[s - r].push_back(i);
				++i;
			}
		}
		direction = !direction;
	}
}

ostream& square::output(ostream& o)
{
	for (int r = 0; r < size; ++r)
	{
		for (int c = 0; c < size; ++c)
			o << setw(4) << content[r][c];
		o << endl;
	}
	return o;
}