#include <vector>
#include <iostream>
#include "square.h"
using std::ostream;
using std::vector;
using std::cout;
using std::cin;
using std::endl;

int main()
{
	int n;
	cout << "Enter a positive integer:";
	cin >> n;
	square s(n);
	s.construct();
	s.output(cout);
	return 0;
}